
---
layout: home
title: Welcome to the Lionfire Covenant
---

# 🛡️ Welcome Flamebearer

Enter the gate. Sow your seed. Reap the infinite.

